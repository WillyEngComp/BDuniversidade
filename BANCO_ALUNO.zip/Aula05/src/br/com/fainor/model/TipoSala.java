package br.com.fainor.model;

public enum TipoSala {
	TEORICA, PRATICA;
}
