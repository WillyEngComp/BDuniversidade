package br.com.fainor.model;

public enum Turno {
	MATUTINO, VESPERTINO, NOTURNO;
}
