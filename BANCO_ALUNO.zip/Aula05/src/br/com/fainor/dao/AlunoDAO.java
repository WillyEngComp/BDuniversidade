package br.com.fainor.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.fainor.model.Aluno;

public class AlunoDAO{
	
	public List<Aluno> todos(){
		
		List<Aluno> alunos = new ArrayList<>();
		
		alunos.add(new Aluno(1L,"Logan Wolverine", "2317465168432","32198465198"));	
		alunos.add(new Aluno(2L,"Juca da Silva", "26546523265168432","321984651989825"));	
		alunos.add(new Aluno(3L,"Aluno Teste 3L", "0010020060058","25241258778"));	
		alunos.add(new Aluno(4L,"Aluno Teste 4l", "001002003004005","2258565869821"));	
		return alunos;
	}
	
	public Aluno porId(Long id){
		for(Aluno aluno: todos()){
			if(aluno.getId()== id){
				return aluno;
			}
		}
		return null;
	}
}

